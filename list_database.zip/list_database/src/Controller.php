<?php

namespace App;
use App\Helper;

class Controller
{
    protected function render($view, $data = [])
    {
        extract($data);
        include "Views/$view.php";
    }
    public function dd($data) {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
        die();
    }
}

