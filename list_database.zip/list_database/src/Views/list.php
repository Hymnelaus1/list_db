<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>test</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.js" integrity="sha512-TV1UlDAJWH0asrDpaia2S8380GMp6kQ4S6756j3Vv2IwglqZc3w2oR6TxN/fOYfAzNpj2WQJUiuel9a7lbH8rA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.css" integrity="sha512-uE3H1RGE5HkSD6RqI8zbKiSCevsWKVi/74GXOSiu0+IcHO3pkLG+Ouzmn1sB6Be5Y6f+3fuIkGxsieEIUrgMTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>

<body class="text-bg-secondary p-3">
    

    <form id="updateForm" class="classic" method="POST">

        <div id="profileInputs" class="input-group mb-3">
            <div class="profile">
                <label>Name:</label>
                <input type="text" name="isim" required class="form-control" >
                <label>Surname:</label>
                <input type="text" name="soyisim" required class="form-control">
                <label>E-mail:</label>
                <input type="email" name="email" required class="form-control">
                <label>Age:</label>
                <input type="number" name="yas" required class="form-control">
            </div>
        </div>
        <input type="submit" id="insertBtn" value="Insert" class="btn btn-success"><br><br>
    </form>
    <div class="position-absolute top-0 end-0">
        <button type="submit" id="logoutBtn" value="Logout" class="btn btn-warning">Logout</button><br>
    </div>
    

    <div id="tableContainer">

    </div>


    <div id="profileData"></div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        function ajax(type, url, data = []) {

            let ajax_data = {
                type: type,
                url: url,
                success: function(response) {
                    return {
                        status: 'success',
                        data: response
                    }
                },
                error: function(response) {
                    return {
                        status: 'failed',
                        data: response
                    }
                }
            }
            if (type === 'POST') {
                ajax_data.data = data
            }

            return $.ajax(ajax_data)
        }
        $(document).ready(function() {


            $.ajax({
                type: 'GET',
                url: '/tablelist',
                success: function(response) {
                    var data = JSON.parse(response);
                    var tableHtml = "<table border='1' cellpadding='5' cellspacing='0' class='table table-dark table-striped'><tr><th>ID</th><th>Name</th><th>Surname</th><th>Age</th><th>E-Mail</th><th>Actions</th></tr>";

                    for (var i = 0; i < data.length; i++) {
                        tableHtml += "<tr>";
                        tableHtml += "<td>" + data[i].id + "</td>";
                        tableHtml += "<td>" + data[i].name + "</td>";
                        tableHtml += "<td>" + data[i].surname + "</td>";
                        tableHtml += "<td>" + data[i].age + "</td>";
                        tableHtml += "<td>" + data[i].e_mail + "</td>";
                        tableHtml += '<td><input type="button" value="Remove" class="btn btn-danger remove_btn" data-id="' + data[i].id + '"> <input type="button" value="Update" class="btn btn-primary update_btn" data-id="' + data[i].id + '"></td>';
                        tableHtml += "</tr>";
                    }


                    tableHtml += "</table>";
                    document.getElementById("tableContainer").innerHTML = tableHtml;


                    $('.remove_btn').on("click", function(e) {

                        const swalWithBootstrapButtons = Swal.mixin({
                            customClass: {
                                confirmButton: "btn btn-success",
                                cancelButton: "btn btn-danger"
                            },
                            buttonsStyling: false
                        });
                        swalWithBootstrapButtons.fire({
                            title: "Are you sure?",
                            text: "You won't be able to revert this!",
                            icon: "warning",
                            showCancelButton: true,
                            confirmButtonText: "Yes, delete it!",
                            cancelButtonText: "No, cancel!",
                            reverseButtons: true
                        }).then((result) => {
                            if (result.isConfirmed) {

                                $result1 = ajax('POST', '/ajax/remove', {
                                    id: userId
                                })
                                if (result1 = 'success') {
                                    swalWithBootstrapButtons.fire({
                                        title: "Deleted!",
                                        text: "Your file has been deleted.",
                                        icon: "success",
                                    });
                                    sleep(2000).then(() => {
                                        location.reload()
                                    });
                                } else if (result1 = 'failed') {
                                    console.log('failed')
                                }

                                //---------------------------------------------------------------------------------
                            } else if (
                                result.dismiss === Swal.DismissReason.cancel
                            ) {
                                swalWithBootstrapButtons.fire({
                                    title: "Cancelled",
                                    text: "Your data is safe :)",
                                    icon: "error"
                                });
                            }
                        });
                        var userId = $(this).data('id');

                    });


                    $('.update_btn').on("click", function(e) {
                        e.preventDefault();
                        var userId = $(this).data('id');

                        $.ajax({
                            type: 'POST',
                            url: '/ajax/edit',
                            data: {
                                id: userId
                            },
                            success: async function(response) {
                                var data = JSON.parse(response);
                                const {
                                    value: formValues
                                } = await Swal.fire({
                                    title: "Update User Information",
                                    html: `
                <input id="update_name" class="swal2-input" value="${data.name}" type="text" placeholder="Name">
                <input id="update_surname" class="swal2-input" value="${data.surname}" type="text" placeholder="Surname">
                <input id="update_age" class="swal2-input" value="${data.age}" type="number" placeholder="Age">
                <input id="update_email" class="swal2-input" value="${data.e_mail}" type="email" placeholder="Email">
            `,
                                    focusConfirm: false,
                                    preConfirm: () => {
                                        return {
                                            name: document.getElementById('update_name').value,
                                            surname: document.getElementById('update_surname').value,
                                            age: document.getElementById('update_age').value,
                                            email: document.getElementById('update_email').value
                                        };
                                    }
                                });

                                if (formValues) {
                                    $.ajax({
                                        type: 'POST',
                                        url: '/ajax/updateUser',
                                        data: {
                                            newValues: formValues,
                                            changeid: userId
                                        },
                                        success: function(response) {
                                            Swal.fire({
                                                position: "center",
                                                icon: "success",
                                                title: "success",
                                                showConfirmButton: false,
                                                timer: 1500
                                            });

                                            sleep(2000).then(() => {
                                                location.reload()
                                            });

                                        },
                                        error: function(xhr, status, error) {
                                            // Handle error
                                            console.error('Error updating user information:', error);
                                        }
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Error fetching user data:', error);
                            }
                        });
                    });
                },
                error: function(response) {
                    alert('Error occurred.');
                }
            });


            $('#insertBtn').click(function(e) {
                e.preventDefault();

                var form_data = $('#updateForm').serializeArray();
                $result = ajax('POST', '/ajax/add', form_data);
                if (result = 'success') {
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "Your work has been saved",
                        showConfirmButton: false,
                    });
                    sleep(2000).then(() => {
                        location.reload()
                    });
                } else if (result = 'failed') {
                    console.log('failed')
                }


            });

            $('#logoutBtn').click(function(e){
                e.preventDefault();
                $result = ajax('POST','ajax/logout')
                if(result ='success'){
                    location.reload()
                }
            })


        });
    </script>
</body>

</html>