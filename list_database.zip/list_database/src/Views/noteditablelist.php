<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.css" integrity="sha512-uE3H1RGE5HkSD6RqI8zbKiSCevsWKVi/74GXOSiu0+IcHO3pkLG+Ouzmn1sB6Be5Y6f+3fuIkGxsieEIUrgMTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="text-bg-secondary p-3">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Hymnelaus</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/home">Home</a></li>
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/login">Login</a></li>
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/noteditablelist">List</a></li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div id="tableContainer" class="mt-3"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $.ajax({
                type: 'GET',
                url: '/tablelist',
                success: function(response) {
                    var data = JSON.parse(response);
                    var tableHtml = "<table border='1' cellpadding='5' cellspacing='0' class='table table-dark table-striped'><tr><th>ID</th><th>Name</th><th>Surname</th><th>Age</th><th>E-Mail</th></tr>";

                    for (var i = 0; i < data.length; i++) {
                        tableHtml += "<tr>";
                        tableHtml += "<td>" + data[i].id + "</td>";
                        tableHtml += "<td>" + data[i].name + "</td>";
                        tableHtml += "<td>" + data[i].surname + "</td>";
                        tableHtml += "<td>" + data[i].age + "</td>";
                        tableHtml += "<td>" + data[i].e_mail + "</td>";
                        tableHtml += "</tr>";
                    }

                    tableHtml += "</table>";
                    $("#tableContainer").html(tableHtml);
                },
                error: function(response) {
                    alert('Error occurred.');
                }
            });
        });
    </script>
</body>

</html>