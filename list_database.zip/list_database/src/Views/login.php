<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Home</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.js" integrity="sha512-TV1UlDAJWH0asrDpaia2S8380GMp6kQ4S6756j3Vv2IwglqZc3w2oR6TxN/fOYfAzNpj2WQJUiuel9a7lbH8rA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.12.1/sweetalert2.min.css" integrity="sha512-uE3H1RGE5HkSD6RqI8zbKiSCevsWKVi/74GXOSiu0+IcHO3pkLG+Ouzmn1sB6Be5Y6f+3fuIkGxsieEIUrgMTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class=>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Hymnelaus</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/home">Home</a></li>
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/login">Login</a></li>
                    <li class="nav-item" icon="\src\Views\list.png"><a class="nav-link active" aria-current="page" href="http://localhost:3600/noteditablelist">List</a></li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="text-center mt-5">
            <h1>Hymnelaus Data Base</h1>
            <div id="login page">
                <form id="loginForm" method="POST">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Username</label>
                        <input type="username" class="form-control" id="login_username" name="login_username" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" class="form-control mb3" id="login_pw" name="login_pw">
                    </div>
                    <button type="submit" class="btn btn-primary" id="loginBtn">Login</button>
                    <button type="submit" class="btn btn-success" id="registerBtn">Register</button>
                </form>
                </form>
            </div>
        </div>
    </div>

    <script>
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }


        $(document).ready(function() {
            $('#loginBtn').click(async function(e) {
                e.preventDefault();

                var user_login_data = $('#loginForm').serialize();

                try {
                    var data = await $.ajax({
                        type: 'POST',
                        url: '/ajax/check_data',
                        data: user_login_data,
                        dataType: 'json'
                    });

                    if (data.status == true) {
                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "Login Successfully",
                            showConfirmButton: false,
                            timer: 1500,
                        });
                        window.location.href = "http://localhost:3600/list";
                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Oops",
                            text: "Wrong username or password",
                        });
                    }
                } catch (error) {
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: "An error occurred while processing your request",
                        footer: '<a href="#">Why do I have this issue?</a>'
                    });
                }
            });

            $('#registerBtn').click(async function(e) {
                e.preventDefault();
                try {
                    const {
                        value: formValues
                    } = await Swal.fire({
                        title: "Register Menu",
                        html: `
                <input id="registered_username" class="swal2-input" type="text" placeholder="Username">
                <input id="registered_password" class="swal2-input" type="password" placeholder="Password">
                <input id="registered_email" class="swal2-input" type="email" placeholder="Email">
                <input id="registered_phonenumber" class="swal2-input" type="text" placeholder="Phone Number">
            `,
                        showCancelButton: true,
                        confirmButtonText: 'Register',
                        cancelButtonText: 'Cancel',
                        focusConfirm: false,
                        preConfirm: () => {
                            return {
                                username: document.getElementById('registered_username').value,
                                password: document.getElementById('registered_password').value,
                                email: document.getElementById('registered_email').value,
                                phonenumber: document.getElementById('registered_phonenumber').value
                            };
                        }
                    });

                    if (formValues) {
                        $.ajax({
                            type: 'POST',
                            url: '/ajax/register',
                            data: {
                                newValues: formValues,
                            },
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire({
                                        position: "center",
                                        icon: "success",
                                        title: "Registration Successful",
                                        showConfirmButton: false,
                                        timer: 1500
                                    }).then(() => {
                                        location.reload();
                                    });
                                } else {
                                    Swal.fire({
                                        icon: "error",
                                        title: "Registration Failed",
                                        text: response.error || "Unknown error occurred",
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Error:', error);
                                Swal.fire({
                                    icon: "error",
                                    title: "Error",
                                    text: "An error occurred while processing your registration",
                                });
                            }
                        });
                    }
                } catch (error) {
                    console.error(error);
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: "An error occurred while processing your registration",
                    });
                }
            });
        });
    </script>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script></script>
</body>

</html>