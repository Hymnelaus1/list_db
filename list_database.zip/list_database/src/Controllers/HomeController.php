<?php

namespace App\Controllers;

use App\Controller;
use App\Models\Journal;
use App\Controllers\DbController;




class HomeController extends Controller
{
    private $db_controller;
    public function __construct()
    {
        $this->db_controller = new DbController();
    }
    public function index()
    {
        if (isset($_SESSION["test"]) and $_SESSION["test"]) {
            header("Location: http://localhost:3600/list");
            exit;
        } else {
            header("Location: http://localhost:3600/login");
            exit;
        }
    }

    public function login()
    {
        if (isset($_SESSION["test"]) and $_SESSION["test"]) {
            header("Location: http://localhost:3600/");
            exit;
        }

        $this->render('login');
    }
    public function home(){
        $this->render('home_page');
    }
    public function user_list()
    {
        if (isset($_SESSION["test"]) and $_SESSION["test"]) {
            $this->render('list');
        } else {
            header("Location: http://localhost:3600/login");
            exit;
        }
    }
    public function noteditablelist()
    {

        $this->render("noteditablelist");
    }
    public function list()
    {

        if ($_SERVER['REQUEST_METHOD'] == 'GET') {
            $sc_student_list = $this->db_controller->select("SELECT * FROM sc_student");
            echo (json_encode($sc_student_list, true));
        }
    }

    public function ajax_add()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $isim = $_POST['isim'];
            $soyisim = $_POST['soyisim'];
            $email = $_POST['email'];
            $yas = $_POST['yas'];

            //db_insert
            $this->db_controller->insert("INSERT INTO sc_student (name, surname, age, e_mail) VALUES ('$isim', '$soyisim', $yas , '$email')");
            //db_insert
        } else {
            echo "Invalid request method";
        }
    }
    public function ajax_edit()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            if (isset($_POST['id']) && !empty($_POST['id'])) {
                $id = (int)$_POST['id'];
                $sc_student_update_id = $this->db_controller->select("SELECT * FROM sc_student WHERE id = $id");
                echo json_encode($sc_student_update_id[0]);
            }
        }
    }
    public function ajax_remove()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id = $_POST["id"];
            $this->db_controller->delete("DELETE FROM sc_student WHERE id = '$id';");
        }
    }
    public function ajax_updateUser()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $changeid = $_POST["changeid"];
            $newValues = $_POST["newValues"];
            $newName = $newValues['name'];
            $newSurname = $newValues['surname'];
            $newAge = $newValues['age'];
            $newEmail = $newValues['email'];
            $result = $this->db_controller->update("UPDATE sc_student SET name = '$newName', surname = '$newSurname', age = $newAge, e_mail = '$newEmail' WHERE id = $changeid");
            echo json_encode($result);
        }
    }
    public function ajax_check_data()
    {
        $response = [
            'status' => false,
            'message' => 'Invalid credentials'
        ];

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $username = $_POST["login_username"];
            $password = $_POST["login_pw"];

            $result = $this->db_controller->select("SELECT * FROM user_accounts WHERE username = '$username' AND password ='$password' ");

            if (($result)) {
                $response['status'] = true;
                $response['message'] = 'Login successful';
                $session_id = uniqid();
                $this->db_controller->update("UPDATE user_accounts SET session_id = '$session_id' WHERE id = " . $result[0]['id']);
                $_SESSION['test'] = $session_id;
            } else {
                $_SESSION['test'] = false;
            }

            echo json_encode($response);
        }
    }
    public function ajax_logout()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            session_destroy();
        } else {
            echo "Invalid request method";
        }
    }
    public function ajax_register()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $newValues = $_POST["newValues"];
            $isim = $newValues['username'];
            $sifre = $newValues['password'];
            $email = $newValues['email'];
            $phonenumber = $newValues['phonenumber'];

            $this->db_controller->insert("INSERT INTO user_accounts (username, password, email, phone_number) VALUES ('$isim', '$sifre', '$email', $phonenumber)");
           
        }
    }
}
