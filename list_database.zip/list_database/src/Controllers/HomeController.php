<?php

namespace App\Controllers;

use App\Controller;
use App\Models\Journal;
use App\Controllers\DbController;




class HomeController extends Controller
{
    private $db_controller;
    public function __construct()
    {
        $this->db_controller = new DbController();
    }
    public function index()
    {
        $journals = [
            new Journal('My Third Journal Entry', '2023'),
            new Journal('My Second Journal Entry', '2022'),
            new Journal('My First Journal Entry', '2021')
        ];
        $this->render('index', ['journals' => $journals]);
    }

    public function list()
    {

        if ($_SERVER['REQUEST_METHOD'] == 'GET') {
            $sc_student_list = $this->db_controller->select("SELECT * FROM sc_student");
            echo (json_encode($sc_student_list, true));
        }
    }

    public function ajax()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $pnumber = $_POST['pnumber'];
            $isim = $_POST['isim'];
            $soyisim = $_POST['soyisim'];
            $email = $_POST['email'];
            $yas = $_POST['yas'];

            if (count($isim) == $pnumber) {
                echo "<table border='1' cellpadding='5' cellspacing='0'>";
                echo "<tr>";
                echo "<th>Name</th>";
                echo "<th>Surname</th>";
                echo "<th>E-Mail</th>";
                echo "<th>Age</th>";
                echo "<th>Action</th>";
                echo "</tr>";

                for ($i = 0; $i < $pnumber; $i++) {
                    $name = $isim[$i];
                    $surname = $soyisim[$i];
                    $email = $email[$i];
                    $age =  $yas[$i];

                    echo "<tr>";
                    echo "<td>$name</td>";
                    echo "<td>$surname</td>";
                    echo "<td>$email</td>";
                    echo "<td>$age</td>";
                    echo "<td>
                    </td>";
                    echo "</tr>";
                }
                //db delete
                // $this->db_controller->delete("DELETE FROM sc_student WHERE name = '$name' AND surname = '$surname'");
                //db delete


                echo "</table>";
            } else {
                echo "Profile number is not matching with created profiles";
            }
            $this->dd($_POST);
        } else {
            echo "Invalid request method";
        }
    }
    public function ajax_add(){
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $isim = $_POST['isim'];
            $soyisim = $_POST['soyisim'];
            $email = $_POST['email'];
            $yas = $_POST['yas'];

            //db_insert
            $this->db_controller->insert("INSERT INTO sc_student (name, surname, age, e_mail) VALUES ('$isim', '$soyisim', $yas , '$email')");
            //db_insert
        } else {
            echo "Invalid request method";
        }
    }
    public function ajax_edit()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            if (isset($_POST['id']) && !empty($_POST['id'])) {
                $id = (int)$_POST['id'];
                $sc_student_update_id = $this->db_controller->select("SELECT * FROM sc_student WHERE id = $id");
                echo json_encode($sc_student_update_id[0]);
            }
        }
    }
    public function ajax_remove()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id = $_POST["id"];
            $this->db_controller->delete("DELETE FROM sc_student WHERE id = '$id';");
        }
    }

    public function ajax_updateUser()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $changeid = $_POST["changeid"];
            $newValues = $_POST["newValues"];
            $newName = $newValues['name'];
            $newSurname = $newValues['surname'];
            $newAge = $newValues['age'];
            $newEmail = $newValues['email'];
            $result = $this->db_controller->update("UPDATE sc_student SET name = '$newName', surname = '$newSurname', age = $newAge, e_mail = '$newEmail' WHERE id = $changeid");
            echo json_encode($result);
        }
    }
}
