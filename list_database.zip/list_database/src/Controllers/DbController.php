<?php

namespace App\Controllers;

use App\Controller;

use mysqli;


class DbController extends Controller
{

    public $conn;
    public function __construct()
    {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = 'deneme';

        // Create connection
        $this->conn = new mysqli($servername, $username, $password, $database);
    }

    public function select($raw_query)
    {
        $data = [];
        $cnn = $this->conn;
        $result = mysqli_query($cnn, $raw_query);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
        }
        return $data;
    }

    public function show($raw_query){
        $cnn = $this->conn;
        $sql = $raw_query;
    }

    public function insert($raw_query)
    {
        $cnn = $this->conn;
        $sql = $raw_query;

        if ($cnn->query($sql) === TRUE) {
        } else {
            echo "Error: " . $sql . "<br>" . $cnn->error;
        }
    }

    public function update($raw_query)
    {
        $result = [
            'status' => false,
            'message' => 'update failed'
        ];

        $cnn = $this->conn;
        $sql = $raw_query;
        if ($cnn->query($sql) === TRUE) {
            $result['status'] = true;
            $result['message'] = 'record uptaded successfully';
        } else {
            $result['message'] = "Error: " . $sql . "<br>" . $cnn->error;
        }

        $cnn->close();
        return $result;
    }

    public function delete($raw_query)
    {
        $cnn = $this->conn;
        $sql = $raw_query;
        if ($cnn->query($sql) === TRUE) {
            echo "record deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $cnn->error;
        }
    }
}
