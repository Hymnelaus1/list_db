<?php

use App\Controllers\HomeController;
use App\Router;

$router = new Router();

$router->get('/', HomeController::class, 'index');

$router->get('/login', HomeController::class, 'login');

$router->get('/list', HomeController::class,'user_list');

$router->get('/tablelist', HomeController::class, 'list');

$router->get('/noteditablelist', HomeController::class,'noteditablelist');

$router->get('/home', HomeController::class,'home');

//--------------------------------------------------------------


$router->post('/test', HomeController::class, 'ajax');

$router->post('/ajax/register', HomeController::class, 'ajax_register');

$router->post('/ajax/check_data', HomeController::class, 'ajax_check_data');

$router->post('/ajax/add', HomeController::class, 'ajax_add');

$router->post('/ajax/edit', HomeController::class, 'ajax_edit');

$router->post('/ajax/remove', HomeController::class, 'ajax_remove');

$router->post('/ajax/updateUser', HomeController::class, 'ajax_updateUser');

$router->post('/ajax/logout', HomeController::class, 'ajax_logout');

$router->dispatch();

