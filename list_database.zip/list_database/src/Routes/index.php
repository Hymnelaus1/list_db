<?php

use App\Controllers\HomeController;
use App\Router;

// Create a new instance of the Router
$router = new Router();

// Define a GET route for the root URI '/'
$router->get('/', HomeController::class, 'index');

$router->get('/tablelist', HomeController::class, 'list');



// Define a POST route for the '/test' URI
$router->post('/test', HomeController::class, 'ajax');

$router->post('/ajax/add', HomeController::class, 'ajax_add');

$router->post('/ajax/edit', HomeController::class, 'ajax_edit');

$router->post('/ajax/remove', HomeController::class, 'ajax_remove');

$router->post('/ajax/updateUser', HomeController::class, 'ajax_updateUser');

// Dispatch the request to the appropriate controller/action based on the defined routes
$router->dispatch();

