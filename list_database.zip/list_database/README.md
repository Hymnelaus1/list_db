# simple-php-mvc-starter

1. Clone the project
2. Run `composer sump-autoload`
3. Run `php -S localhost:9999`
